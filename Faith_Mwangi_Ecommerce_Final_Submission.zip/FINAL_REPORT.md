# DESIGN AND IMPLEMENTATION OF AN E-COMMERCE WEBSITE WITH M-PESA PAYMENT INTEGRATION

## Student Project Report

### Abstract
K-Shop is a web-based e-commerce application designed to provide customers with a simple way of viewing products, searching for products, adding products to a shopping cart and placing orders. The system is implemented using Python Flask, SQLite, HTML, CSS and JavaScript. A demonstration M-PESA checkout flow is included to show how mobile-money payment can fit into an online shopping process.

### 1. Introduction
E-commerce enables businesses to present products online and receive orders without requiring customers to visit a physical shop. This project demonstrates the development of a small e-commerce system suitable for a student project.

### 2. Problem Statement
Small businesses may rely on physical sales and manual order processing. Customers may have difficulty viewing available products remotely and completing an organized purchase. K-Shop addresses this by providing an online product catalogue, cart and checkout process.

### 3. Objectives
1. To design an easy-to-use e-commerce website.
2. To display goods and their prices online.
3. To provide product searching and categorization.
4. To implement a shopping cart.
5. To store products and orders using SQLite.
6. To demonstrate an M-PESA payment workflow.
7. To provide basic product administration.

### 4. Technologies
- Python 3
- Flask
- SQLite
- HTML5
- CSS3
- JavaScript

### 5. System Modules
- Home page
- Product catalogue
- Search and categories
- Product details
- Shopping cart
- Checkout
- M-PESA demonstration
- Order management
- Product administration

### 6. Database Design
The `products` table stores product information including name, category, description, price and image reference. The `orders` table stores customer details, order total, payment status and order date.

### 7. M-PESA Integration
The submitted version contains a demonstration payment flow. It records a successful demo payment after checkout. A production Daraja integration requires authorized Safaricom Daraja credentials, a business short code, passkey and a publicly reachable callback endpoint. The live integration should therefore be configured only with authorized credentials.

### 8. Testing Plan
The system should be demonstrated by:
- Opening the home page.
- Viewing products.
- Searching for a product.
- Filtering by category.
- Opening product details.
- Adding an item to the cart.
- Removing an item.
- Checking out.
- Entering a customer name, phone number and address.
- Completing the demo M-PESA payment.
- Viewing the generated order.
- Adding and deleting a product from the admin page.

### 9. Security Considerations
The project should use environment variables for production secrets. Real payment credentials must not be hard-coded or shared. A production system should also add authentication, CSRF protection, stronger input validation and secure deployment.

### 10. Conclusion
K-Shop demonstrates the main components of a basic e-commerce application and provides a foundation for a production system. The architecture can be extended with customer accounts, stock management, real Daraja STK Push, delivery tracking, image uploads and deployment to a public server.
