FAITH MWANGI — K-SHOP E-COMMERCE PROJECT

PROJECT TITLE
Design and Implementation of an E-Commerce Website with M-PESA Payment Integration

CONTENTS
- app.py — Flask backend
- shop.db — SQLite database
- templates/ — website pages
- static/ — CSS and JavaScript
- create_db.py — database initialization
- requirements.txt — dependency
- FINAL_REPORT.md — project report
- demo.html — browser-openable demonstration
- README.md — technical instructions

QUICK DEMONSTRATION
Open demo.html in any web browser to see the interface, add products to the
cart and test the checkout demonstration.

FULL FLASK VERSION
Install Python, then run:
pip install -r requirements.txt
python app.py
Open http://127.0.0.1:5000

PAYMENT NOTE
The included M-PESA flow is a demonstration and does not process real money.
A live Safaricom Daraja STK Push requires authorized credentials, a business
short code/passkey and a publicly reachable callback endpoint. Those credentials
are intentionally not included.

STUDENT
Faith Mwangi
