from app import init_db
init_db()
print("Database created successfully: shop.db")
