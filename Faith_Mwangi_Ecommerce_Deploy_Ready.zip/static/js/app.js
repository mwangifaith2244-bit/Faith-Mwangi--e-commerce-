document.addEventListener("DOMContentLoaded", () => {
    const buttons = document.querySelectorAll("form button");
    buttons.forEach(btn => {
        btn.addEventListener("click", () => {
            btn.style.opacity = "0.8";
        });
    });
});
